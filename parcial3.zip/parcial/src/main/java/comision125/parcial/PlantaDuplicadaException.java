package comision125.parcial;

public class PlantaDuplicadaException extends Exception {
    public PlantaDuplicadaException(String message) {
        super(message);
    }
}

