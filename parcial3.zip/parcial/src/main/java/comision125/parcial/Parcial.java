package comision125.parcial;

public class Parcial {
    public static void main(String[] args) {
        try {
            JardinBotanico jardin = new JardinBotanico();

            Arbol arbol1 = new Arbol("Arbolito", "Sur", "Calor", 30);
            Arbusto arbusto1 = new Arbusto("Arbustito", "Norte", "Frio", 11); // Fuera de rango
            Flor rosa1 = new Flor("Rosa", "Norte", "Templado", Temporada.PRIMAVERA);
            Arbol arbol2 = new Arbol("Arbolito", "Sur", "Calor", 30); // Duplicado

            
            jardin.agregarPlanta(arbusto1);
            jardin.agregarPlanta(arbol1);
            jardin.agregarPlanta(rosa1);
            
            System.out.println("Mostrando las plantas:");
            jardin.mostrarPlantas();

            System.out.println("\nPodando plantas:");
            jardin.podarPlantas();
            
        } catch (PlantaDuplicadaException e) {
            System.out.println(e.getMessage());
        }
    }
}
