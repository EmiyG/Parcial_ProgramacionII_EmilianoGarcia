package comision125.parcial;

public class Arbol extends Planta {
    private double alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public void podar() {
        System.out.println(nombre + " ha sido podado.");
    }

    @Override
    public String toString() {
        return "Arbol [Nombre: " + nombre + ", Ubicacion: " + ubicacion + ", Clima: " + clima +
                ", Altura Maxima: " + alturaMaxima + " m]";
    }
}