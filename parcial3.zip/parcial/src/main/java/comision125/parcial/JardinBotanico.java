package comision125.parcial;

import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {
    private List<Planta> plantas;

    public JardinBotanico() {
        this.plantas = new ArrayList<>();
    }

    public void agregarPlanta(Planta planta) throws PlantaDuplicadaException {
        for (Planta p : plantas) {
            if (p.nombre.equals(planta.nombre) && p.ubicacion.equals(planta.ubicacion)) {
                throw new PlantaDuplicadaException("Ya existe una planta con el mismo nombre y ubicacion.");
            }
        }
        plantas.add(planta);
    }

    public void mostrarPlantas() {
        if (plantas.isEmpty()) {
            System.out.println("No hay plantas en el jardin para mostar.");
        } else {
            for (Planta planta : plantas) {
                System.out.println(planta);
            }
        }
    }

    public void podarPlantas() {
        for (Planta planta : plantas) {
            if (planta instanceof Arbol || planta instanceof Arbusto) {
                planta.podar();
            } else {
                System.out.println("La flor " + planta.nombre + " no puede ser podada.");
            }
        }
    }
}

