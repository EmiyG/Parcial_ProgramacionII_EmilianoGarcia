package comision125.parcial;

public class Arbusto extends Planta {
    private int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        if (densidadFollaje < 1 || densidadFollaje > 10) {
            System.out.println("ERROR. Por favor, ingresa una densidad de follaje entre 1 y 10. Se le asigna por defecto 1");
            this.densidadFollaje = 1; // Le asigno por defecto una densidad de follaje si no es valida.
        } else {
            this.densidadFollaje = densidadFollaje;
        }
    }

    @Override
    public void podar() {
        System.out.println(nombre + " ha sido podado.");
    }

    @Override
    public String toString() {
        return "Arbusto [Nombre: " + nombre + ", Ubicacion: " + ubicacion + ", Clima: " + clima +
                ", Densidad Follaje: " + densidadFollaje + "]";
    }
}
