package comision125.parcial;

enum Temporada {
    PRIMAVERA, VERANO, OTOÑO, INVIERNO
}