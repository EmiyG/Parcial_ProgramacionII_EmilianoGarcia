package comision125.parcial;

public abstract class Planta {
    protected String nombre;
    protected String ubicacion;
    protected String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    public void podar() {
        System.out.println(nombre + " ha sido podado.");
    }


    @Override
    public abstract String toString();
}